import os
import glob
import pandas as pd

def load_data(data_dir):
    """
    Load audio files from the specified directory.
    Assumes RAVDESS naming convention for labels if applicable,
    or falls back to folder names.
    
    RAVDESS Filename Identifiers:
    Modality (01 = full-AV, 02 = video-only, 03 = audio-only).
    Vocal channel (01 = speech, 02 = song).
    Emotion (01 = neutral, 02 = calm, 03 = happy, 04 = sad, 05 = angry, 06 = fearful, 07 = disgust, 08 = surprised).
    Intensity (01 = normal, 02 = strong).
    Statement (01 = "Kids are talking...", 02 = "Dogs are sitting...").
    Repetition (01 = 1st repetition, 02 = 2nd repetition).
    Actor (01 to 24. Odd numbered actors are male, even numbered actors are female).
    
    Target Mapping:
    01 (Neutral) -> Neutral
    02 (Calm) -> Calm
    03 (Happy) -> Neutral (or exclude?) -> Let's map Happy to Neutral for now or exclude.
    04 (Sad) -> Stressed (Low/Med?) -> Let's map Sad, Angry, Fearful to Stressed.
    """
    
    file_paths = []
    labels = []
    
    # Recursive search for wav files
    wav_files = glob.glob(os.path.join(data_dir, "**/*.wav"), recursive=True)
    
    for file_path in wav_files:
        filename = os.path.basename(file_path)
        parts = filename.split('-')
        
        label = "Unknown"
        
        # Check if it matches RAVDESS format (7 parts, numeric)
        if len(parts) == 7 and all(p.isdigit() for p in parts):
            emotion_code = int(parts[2])
            if emotion_code == 1:
                label = "Neutral"
            elif emotion_code == 2:
                label = "Calm"
            elif emotion_code in [3, 4, 5, 6, 7, 8]:
                label = "Stressed" # Grouping negative/high arousal emotions as Stressed
        else:
            # Fallback: try to guess from parent folder name
            parent_dir = os.path.basename(os.path.dirname(file_path)).lower()
            if "neutral" in parent_dir:
                label = "Neutral"
            elif "calm" in parent_dir:
                label = "Calm"
            elif "stress" in parent_dir or "angry" in parent_dir or "fear" in parent_dir:
                label = "Stressed"
                
        if label != "Unknown":
            file_paths.append(file_path)
            labels.append(label)
            
    df = pd.DataFrame({
        "path": file_paths,
        "label": labels
    })
    
    return df

if __name__ == "__main__":
    # Test
    print("Testing data loader...")
    df = load_data("data/raw")
    print(f"Found {len(df)} samples.")
    print(df['label'].value_counts())
