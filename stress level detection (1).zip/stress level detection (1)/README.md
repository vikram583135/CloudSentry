# Stress Level Detection Using Voice Tone

🎙️ An AI-powered system that detects stress levels (Calm, Neutral, Stressed) from human speech using audio signal processing and machine learning.

## 📦 Project Structure

```
stress-detection/
├── app.py                  # Streamlit web interface
├── requirements.txt        # Python dependencies
├── data/
│   ├── raw/               # Audio files for training
│   └── processed/         # Extracted features
├── models/                # Trained ML models
└── src/
    ├── preprocessing.py   # Audio cleaning & normalization
    ├── features.py        # Feature extraction (MFCCs, pitch, etc.)
    ├── model.py           # Model training & prediction
    ├── data_loader.py     # Dataset loading utilities
    └── generate_dummy_data.py  # Synthetic data generator
```

## 🚀 Quick Start

### 1. Install Dependencies
```bash
python3 -m pip install -r requirements.txt
```

### 2. Generate Training Data (Optional)
If you don't have real audio data:
```bash
python3 src/generate_dummy_data.py
```

### 3. Train the Model
```bash
python3 src/model.py
```

### 4. Run the Web App
```bash
python3 -m streamlit run app.py
```

## 🎯 How It Works

1. **Audio Preprocessing**: Loads audio, resamples to 16kHz, normalizes volume, trims silence
2. **Feature Extraction**: Extracts 34 acoustic features including:
   - MFCCs (Mel-frequency cepstral coefficients)
   - Zero Crossing Rate
   - Spectral Centroid
   - RMS Energy
   - Pitch (F0)
3. **Classification**: Random Forest classifier predicts stress level
4. **Results**: Web interface shows prediction with confidence score

## 📊 Features Extracted

| Feature | Description |
|---------|-------------|
| MFCCs (13 mean + 13 std) | Voice timbre and tone |
| Zero Crossing Rate | Signal noisiness |
| Spectral Centroid | Sound brightness |
| RMS Energy | Loudness |
| Pitch (F0) | Fundamental frequency |

## 🔧 Using Real Datasets

For better accuracy, use real emotion datasets:
- **RAVDESS** (Ryerson Audio-Visual Database)
- **TESS** (Toronto Emotional Speech Set)
- **SAVEE** (Surrey Audio-Visual Expressed Emotion)

Place audio files in `data/raw/` following the folder structure or RAVDESS naming convention.

## 📝 License

This project is for educational purposes (Innovation and Design Thinking Course 2025-26).
