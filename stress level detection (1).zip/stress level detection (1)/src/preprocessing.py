"""
Audio Preprocessing Module for Stress Detection.

This module handles:
- Loading audio files
- Resampling to a consistent sample rate (16kHz)
- Normalizing audio volume
- Trimming silence
"""

import librosa
import numpy as np

# Target sample rate for all audio
TARGET_SR = 16000


def load_audio(file_path, sr=TARGET_SR):
    """
    Load an audio file and resample to the target sample rate.
    
    Args:
        file_path: Path to the audio file
        sr: Target sample rate (default: 16000 Hz)
    
    Returns:
        y: Audio time series (numpy array)
        sr: Sample rate
    """
    y, original_sr = librosa.load(file_path, sr=sr, mono=True)
    return y, sr


def normalize_audio(y):
    """
    Normalize audio to have values between -1 and 1.
    
    Args:
        y: Audio time series
    
    Returns:
        Normalized audio time series
    """
    max_val = np.max(np.abs(y))
    if max_val > 0:
        y = y / max_val
    return y


def trim_silence(y, sr, top_db=20):
    """
    Trim leading and trailing silence from audio.
    
    Args:
        y: Audio time series
        sr: Sample rate
        top_db: Threshold in decibels below reference to consider as silence
    
    Returns:
        Trimmed audio time series
    """
    y_trimmed, _ = librosa.effects.trim(y, top_db=top_db)
    return y_trimmed


def preprocess_audio(file_path, sr=TARGET_SR, normalize=True, trim=True):
    """
    Full preprocessing pipeline for a single audio file.
    
    Args:
        file_path: Path to the audio file
        sr: Target sample rate
        normalize: Whether to normalize the audio
        trim: Whether to trim silence
    
    Returns:
        y: Preprocessed audio time series
        sr: Sample rate
    """
    # Load and resample
    y, sr = load_audio(file_path, sr=sr)
    
    # Trim silence
    if trim:
        y = trim_silence(y, sr)
    
    # Normalize
    if normalize:
        y = normalize_audio(y)
    
    return y, sr


if __name__ == "__main__":
    # Test the preprocessing pipeline
    import os
    
    test_file = "data/raw/fake_neutral/03-01-01-01-01-01-01.wav"
    
    if os.path.exists(test_file):
        y, sr = preprocess_audio(test_file)
        print(f"Loaded audio: {len(y)} samples at {sr} Hz")
        print(f"Duration: {len(y) / sr:.2f} seconds")
        print(f"Max amplitude: {np.max(np.abs(y)):.4f}")
    else:
        print(f"Test file not found: {test_file}")
