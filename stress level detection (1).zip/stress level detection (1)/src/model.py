"""
Model Training Module for Stress Detection.

This module handles:
- Loading and preparing the dataset
- Training machine learning models (SVM, Random Forest)
- Evaluating model performance
- Saving the best model for inference
"""

import os
import sys
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data_loader import load_data
from src.features import extract_features_from_file, FEATURE_NAMES

# Paths
MODEL_DIR = "models"
PROCESSED_DATA_DIR = "data/processed"


def prepare_dataset(data_dir="data/raw", save_features=True):
    """
    Load audio files, extract features, and prepare dataset for training.
    
    Args:
        data_dir: Directory containing raw audio files
        save_features: Whether to save extracted features to disk
    
    Returns:
        X: Feature matrix
        y: Labels
        label_encoder: Fitted LabelEncoder
    """
    print("Loading data...")
    df = load_data(data_dir)
    
    if len(df) == 0:
        raise ValueError("No audio files found. Please add audio data to data/raw/")
    
    print(f"Found {len(df)} audio files")
    print(f"Label distribution:\n{df['label'].value_counts()}")
    
    # Extract features for each file
    print("\nExtracting features...")
    features_list = []
    valid_labels = []
    
    for idx, row in df.iterrows():
        try:
            features = extract_features_from_file(row['path'])
            features_list.append(features)
            valid_labels.append(row['label'])
            print(f"  Processed: {os.path.basename(row['path'])}")
        except Exception as e:
            print(f"  Error processing {row['path']}: {e}")
    
    X = np.array(features_list)
    
    # Encode labels
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(valid_labels)
    
    print(f"\nDataset shape: {X.shape}")
    print(f"Classes: {label_encoder.classes_}")
    
    # Save features if requested
    if save_features:
        os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)
        feature_df = pd.DataFrame(X, columns=FEATURE_NAMES)
        feature_df['label'] = valid_labels
        feature_df.to_csv(os.path.join(PROCESSED_DATA_DIR, "features.csv"), index=False)
        print(f"Features saved to {PROCESSED_DATA_DIR}/features.csv")
    
    return X, y, label_encoder


def train_model(X, y, model_type="random_forest"):
    """
    Train a machine learning model.
    
    Args:
        X: Feature matrix
        y: Labels
        model_type: 'random_forest' or 'svm'
    
    Returns:
        model: Trained model
        scaler: Fitted StandardScaler
        metrics: Dictionary with performance metrics
    """
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Split data - use stratify only if we have enough samples per class
    min_samples_per_class = min(np.bincount(y))
    use_stratify = min_samples_per_class >= 2 and len(y) >= 10
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, 
        stratify=y if use_stratify else None
    )
    
    print(f"\nTraining {model_type} model...")
    print(f"Training samples: {len(X_train)}, Test samples: {len(X_test)}")
    
    # Create model
    if model_type == "random_forest":
        model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    elif model_type == "svm":
        model = SVC(kernel='rbf', C=1.0, random_state=42, probability=True)
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    
    # Train
    model.fit(X_train, y_train)
    
    # Predict
    y_pred = model.predict(X_test)
    
    # Metrics
    accuracy = accuracy_score(y_test, y_pred)
    
    metrics = {
        'accuracy': accuracy,
        'classification_report': classification_report(y_test, y_pred, zero_division=0),
        'confusion_matrix': confusion_matrix(y_test, y_pred)
    }
    
    print(f"\nModel Performance:")
    print(f"Accuracy: {accuracy:.4f}")
    print(f"\nClassification Report:\n{metrics['classification_report']}")
    print(f"\nConfusion Matrix:\n{metrics['confusion_matrix']}")
    
    return model, scaler, metrics


def save_model(model, scaler, label_encoder, model_name="stress_detector"):
    """
    Save trained model, scaler, and label encoder.
    
    Args:
        model: Trained sklearn model
        scaler: Fitted StandardScaler
        label_encoder: Fitted LabelEncoder
        model_name: Name for saved files
    """
    os.makedirs(MODEL_DIR, exist_ok=True)
    
    model_path = os.path.join(MODEL_DIR, f"{model_name}_model.joblib")
    scaler_path = os.path.join(MODEL_DIR, f"{model_name}_scaler.joblib")
    encoder_path = os.path.join(MODEL_DIR, f"{model_name}_encoder.joblib")
    
    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)
    joblib.dump(label_encoder, encoder_path)
    
    print(f"\nModel saved to:")
    print(f"  Model: {model_path}")
    print(f"  Scaler: {scaler_path}")
    print(f"  Encoder: {encoder_path}")


def load_trained_model(model_name="stress_detector"):
    """
    Load trained model, scaler, and label encoder.
    
    Returns:
        model, scaler, label_encoder
    """
    model_path = os.path.join(MODEL_DIR, f"{model_name}_model.joblib")
    scaler_path = os.path.join(MODEL_DIR, f"{model_name}_scaler.joblib")
    encoder_path = os.path.join(MODEL_DIR, f"{model_name}_encoder.joblib")
    
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    label_encoder = joblib.load(encoder_path)
    
    return model, scaler, label_encoder


def predict_stress(audio_path, model=None, scaler=None, label_encoder=None):
    """
    Predict stress level from an audio file.
    
    Args:
        audio_path: Path to audio file
        model, scaler, label_encoder: Optional pre-loaded model components
    
    Returns:
        predicted_label: String label (Calm, Neutral, Stressed)
        confidence: Prediction confidence (if available)
    """
    if model is None:
        model, scaler, label_encoder = load_trained_model()
    
    # Extract features
    features = extract_features_from_file(audio_path)
    features_scaled = scaler.transform([features])
    
    # Predict
    prediction = model.predict(features_scaled)[0]
    predicted_label = label_encoder.inverse_transform([prediction])[0]
    
    # Get confidence if available
    confidence = None
    if hasattr(model, 'predict_proba'):
        proba = model.predict_proba(features_scaled)[0]
        confidence = np.max(proba)
    
    return predicted_label, confidence


if __name__ == "__main__":
    # Full training pipeline
    print("=" * 50)
    print("STRESS DETECTION MODEL TRAINING")
    print("=" * 50)
    
    # Prepare dataset
    X, y, label_encoder = prepare_dataset("data/raw")
    
    # Train Random Forest
    model, scaler, metrics = train_model(X, y, model_type="random_forest")
    
    # Save model
    save_model(model, scaler, label_encoder)
    
    print("\n" + "=" * 50)
    print("TRAINING COMPLETE!")
    print("=" * 50)
