"""
Feature Extraction Module for Stress Detection.

Extracts the following acoustic features:
- MFCCs (Mel-frequency cepstral coefficients)
- Zero Crossing Rate
- Spectral Centroid
- RMS Energy
- Pitch (F0 - fundamental frequency)
"""

import librosa
import numpy as np
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.preprocessing import preprocess_audio, TARGET_SR


def extract_mfccs(y, sr, n_mfcc=13):
    """
    Extract MFCC features from audio.
    
    Args:
        y: Audio time series
        sr: Sample rate
        n_mfcc: Number of MFCCs to extract
    
    Returns:
        Mean and std of MFCCs (2 * n_mfcc features)
    """
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    mfcc_mean = np.mean(mfccs, axis=1)
    mfcc_std = np.std(mfccs, axis=1)
    return np.concatenate([mfcc_mean, mfcc_std])


def extract_zcr(y):
    """
    Extract Zero Crossing Rate.
    
    Args:
        y: Audio time series
    
    Returns:
        Mean and std of ZCR
    """
    zcr = librosa.feature.zero_crossing_rate(y)
    return np.array([np.mean(zcr), np.std(zcr)])


def extract_spectral_centroid(y, sr):
    """
    Extract Spectral Centroid (brightness of sound).
    
    Args:
        y: Audio time series
        sr: Sample rate
    
    Returns:
        Mean and std of spectral centroid
    """
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
    return np.array([np.mean(centroid), np.std(centroid)])


def extract_rms_energy(y):
    """
    Extract RMS (Root Mean Square) energy.
    
    Args:
        y: Audio time series
    
    Returns:
        Mean and std of RMS energy
    """
    rms = librosa.feature.rms(y=y)
    return np.array([np.mean(rms), np.std(rms)])


def extract_pitch(y, sr):
    """
    Extract pitch (fundamental frequency F0) using librosa's pyin.
    
    Args:
        y: Audio time series
        sr: Sample rate
    
    Returns:
        Mean and std of pitch (excluding unvoiced frames)
    """
    # Use pyin for pitch tracking
    f0, voiced_flag, voiced_probs = librosa.pyin(
        y, 
        fmin=librosa.note_to_hz('C2'),  # ~65 Hz
        fmax=librosa.note_to_hz('C7'),  # ~2093 Hz
        sr=sr
    )
    
    # Filter out NaN values (unvoiced frames)
    f0_voiced = f0[~np.isnan(f0)]
    
    if len(f0_voiced) > 0:
        return np.array([np.mean(f0_voiced), np.std(f0_voiced)])
    else:
        return np.array([0.0, 0.0])


def extract_all_features(y, sr):
    """
    Extract all features from audio and combine into a single feature vector.
    
    Args:
        y: Audio time series
        sr: Sample rate
    
    Returns:
        Feature vector (numpy array)
    """
    features = []
    
    # MFCCs (26 features: 13 mean + 13 std)
    features.extend(extract_mfccs(y, sr))
    
    # ZCR (2 features)
    features.extend(extract_zcr(y))
    
    # Spectral Centroid (2 features)
    features.extend(extract_spectral_centroid(y, sr))
    
    # RMS Energy (2 features)
    features.extend(extract_rms_energy(y))
    
    # Pitch (2 features)
    features.extend(extract_pitch(y, sr))
    
    return np.array(features)


def extract_features_from_file(file_path):
    """
    Full pipeline: preprocess audio and extract features.
    
    Args:
        file_path: Path to audio file
    
    Returns:
        Feature vector (numpy array)
    """
    y, sr = preprocess_audio(file_path)
    return extract_all_features(y, sr)


# Feature names for reference
FEATURE_NAMES = (
    [f'mfcc_{i}_mean' for i in range(1, 14)] +
    [f'mfcc_{i}_std' for i in range(1, 14)] +
    ['zcr_mean', 'zcr_std'] +
    ['spectral_centroid_mean', 'spectral_centroid_std'] +
    ['rms_mean', 'rms_std'] +
    ['pitch_mean', 'pitch_std']
)


if __name__ == "__main__":
    import os
    
    test_file = "data/raw/fake_neutral/03-01-01-01-01-01-01.wav"
    
    if os.path.exists(test_file):
        features = extract_features_from_file(test_file)
        print(f"Extracted {len(features)} features")
        print(f"Feature names: {FEATURE_NAMES}")
        print(f"Feature values (first 10): {features[:10]}")
    else:
        print(f"Test file not found: {test_file}")
