import numpy as np
import soundfile as sf
import os

def generate_sine_wave(filename, duration=3.0, sr=22050, freq=440.0):
    t = np.linspace(0, duration, int(sr * duration))
    x = 0.5 * np.sin(2 * np.pi * freq * t)
    
    # Add some noise
    noise = np.random.normal(0, 0.01, x.shape)
    x = x + noise
    
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    sf.write(filename, x, sr)
    print(f"Created {filename}")

def generate_dataset():
    base_dir = "data/raw"
    
    # Generate multiple samples per class for proper training
    for i in range(10):
        # Neutral: 03-01-01... (emotion code 01)
        generate_sine_wave(
            os.path.join(base_dir, f"fake_neutral/03-01-01-01-01-{i+1:02d}-01.wav"), 
            freq=440 + np.random.uniform(-50, 50)
        )
        # Calm: 03-01-02... (emotion code 02)
        generate_sine_wave(
            os.path.join(base_dir, f"fake_calm/03-01-02-01-01-{i+1:02d}-01.wav"), 
            freq=220 + np.random.uniform(-30, 30)
        )
        # Stressed (Angry): 03-01-05... (emotion code 05)
        generate_sine_wave(
            os.path.join(base_dir, f"fake_stressed/03-01-05-01-01-{i+1:02d}-01.wav"), 
            freq=880 + np.random.uniform(-100, 100)
        )
    print(f"Generated 30 dummy audio files (10 per class)")

if __name__ == "__main__":
    generate_dataset()
