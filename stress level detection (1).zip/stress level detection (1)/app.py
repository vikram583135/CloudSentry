"""
Stress Level Detection App - Streamlit Interface

This application allows users to:
1. Record audio using microphone
2. Upload an audio file
3. View the audio waveform
4. Get a stress level prediction (Calm, Neutral, Stressed)
"""

import streamlit as st
import numpy as np
import os
import sys
import tempfile
import matplotlib.pyplot as plt
from audio_recorder_streamlit import audio_recorder

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.preprocessing import preprocess_audio, TARGET_SR
from src.features import extract_all_features
from src.model import load_trained_model

# Page configuration
st.set_page_config(
    page_title="Stress Level Detection",
    page_icon="🎙️",
    layout="centered"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .result-box {
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        margin: 1rem 0;
    }
    .calm {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        color: white;
    }
    .neutral {
        background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        color: white;
    }
    .stressed {
        background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
        color: white;
    }
    .confidence-bar {
        height: 10px;
        border-radius: 5px;
        background: rgba(255,255,255,0.3);
        margin-top: 10px;
    }
    .stAudio {
        margin: 1rem 0;
    }
    .recording-section {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 2rem;
        border-radius: 15px;
        text-align: center;
        margin: 1rem 0;
    }
    .input-method-tabs {
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)


def load_model():
    """Load the trained model."""
    try:
        model, scaler, label_encoder = load_trained_model()
        return model, scaler, label_encoder
    except Exception as e:
        st.error(f"Error loading model: {e}")
        st.info("Please run `python src/model.py` first to train the model.")
        return None, None, None


def predict_stress_level(audio_path, model, scaler, label_encoder):
    """Make a stress level prediction from audio file."""
    try:
        # Preprocess
        y, sr = preprocess_audio(audio_path)
        
        # Extract features
        features = extract_all_features(y, sr)
        features_scaled = scaler.transform([features])
        
        # Predict
        prediction = model.predict(features_scaled)[0]
        predicted_label = label_encoder.inverse_transform([prediction])[0]
        
        # Get confidence
        confidence = None
        if hasattr(model, 'predict_proba'):
            proba = model.predict_proba(features_scaled)[0]
            confidence = np.max(proba)
        
        return predicted_label, confidence, y, sr
    except Exception as e:
        st.error(f"Error during prediction: {e}")
        return None, None, None, None


def plot_waveform(y, sr):
    """Plot the audio waveform."""
    fig, ax = plt.subplots(figsize=(10, 3))
    time = np.arange(0, len(y)) / sr
    ax.plot(time, y, color='#667eea', linewidth=0.5)
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Amplitude')
    ax.set_title('Audio Waveform')
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    return fig


def display_results(predicted_label, confidence, y, sr, label_encoder):
    """Display the prediction results."""
    st.markdown("---")
    st.markdown("### 📊 Analysis Results")
    
    # Result box with appropriate styling
    label_class = predicted_label.lower()
    confidence_pct = confidence * 100 if confidence else 0
    
    emoji_map = {
        'calm': '😌',
        'neutral': '😐',
        'stressed': '😰'
    }
    emoji = emoji_map.get(label_class, '🔮')
    
    st.markdown(f"""
    <div class="result-box {label_class}">
        <h1>{emoji}</h1>
        <h2>Stress Level: {predicted_label}</h2>
        <p>Confidence: {confidence_pct:.1f}%</p>
        <div class="confidence-bar" style="width: {confidence_pct}%"></div>
    </div>
    """, unsafe_allow_html=True)
    
    # Display waveform
    st.markdown("### 🌊 Audio Waveform")
    fig = plot_waveform(y, sr)
    st.pyplot(fig)
    
    # Additional info
    with st.expander("ℹ️ Technical Details"):
        st.write(f"- **Duration**: {len(y)/sr:.2f} seconds")
        st.write(f"- **Sample Rate**: {sr} Hz")
        st.write(f"- **Samples**: {len(y):,}")
        st.write(f"- **Classes**: {list(label_encoder.classes_)}")


def process_audio_bytes(audio_bytes, model, scaler, label_encoder):
    """Process audio bytes and make prediction."""
    with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp_file:
        tmp_file.write(audio_bytes)
        tmp_path = tmp_file.name
    
    try:
        # Display audio player
        st.audio(audio_bytes, format='audio/wav')
        
        # Make prediction
        with st.spinner('🔍 Analyzing voice patterns...'):
            predicted_label, confidence, y, sr = predict_stress_level(
                tmp_path, model, scaler, label_encoder
            )
        
        if predicted_label is not None:
            display_results(predicted_label, confidence, y, sr, label_encoder)
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def main():
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🎙️ Stress Level Detection</h1>
        <p>Analyze your voice to detect stress levels using AI</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Load model
    model, scaler, label_encoder = load_model()
    
    if model is None:
        st.stop()
    
    st.success("✅ Model loaded successfully!")
    
    # Instructions
    st.markdown("""
    ### How to use:
    1. **Record** your voice using the microphone OR **Upload** an audio file
    2. Speak naturally for 3-5 seconds (e.g., describe your day)
    3. View your stress level prediction
    """)
    
    # Input method tabs
    tab1, tab2 = st.tabs(["🎤 Record Audio", "📁 Upload File"])
    
    # Tab 1: Microphone Recording
    with tab1:
        st.markdown("""
        <div class="recording-section">
            <h4>🎤 Click the button below to start recording</h4>
            <p>Speak for 3-5 seconds, then click again to stop</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Audio recorder widget
        audio_bytes = audio_recorder(
            text="Click to Record",
            recording_color="#ff4b4b",
            neutral_color="#667eea",
            icon_name="microphone",
            icon_size="2x",
            pause_threshold=3.0,
            sample_rate=16000
        )
        
        if audio_bytes:
            st.success("✅ Recording captured! Processing...")
            process_audio_bytes(audio_bytes, model, scaler, label_encoder)
    
    # Tab 2: File Upload
    with tab2:
        uploaded_file = st.file_uploader(
            "Upload an audio file",
            type=['wav', 'mp3', 'ogg', 'flac'],
            help="Supported formats: WAV, MP3, OGG, FLAC"
        )
        
        if uploaded_file is not None:
            audio_bytes = uploaded_file.getvalue()
            process_audio_bytes(audio_bytes, model, scaler, label_encoder)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style="text-align: center; color: gray; font-size: 0.8rem;">
        <p>🎓 Innovation and Design Thinking Project | 2025-26</p>
        <p>Stress Level Detection Using Voice Tone Analysis</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
